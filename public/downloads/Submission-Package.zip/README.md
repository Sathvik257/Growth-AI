# Campus Relay submission

Submit these four items: downloads/Growth-Plan.pdf (two pages), the working prototype, downloads/AI-LEARNING-NOTES.md, and downloads/Campus-Relay-Walkthrough.mp4 (three minutes, disclosed synthetic narration).

To run the source: extract this ZIP, run `python -m http.server 8766` here and open http://localhost:8766. Alternatively, open downloads/Campus-Relay-Portable.html as a single-file prototype; browser local-file storage policies vary.

Start with downloads/DEMO-GUIDE.md. Use downloads/VIDEO-SCRIPT.md for a personal recording and downloads/INTERVIEW-PREP.md to practice explaining assumptions. Run `node --test tests/operations.test.cjs` for seven decision-logic checks.

All data is fictional and browser-local; no real campaign was executed. Shared storage and verified identities are not implemented. No application was submitted. Deployment is left to the applicant.
